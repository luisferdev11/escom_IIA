/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package funcional;

/**
 *
 * @author EMOA1
 */
public class Aritmetica {
    public static int suma(int x, int y){
        return x + y;
    }
    public static int multiplica(int x, int y){
        return x * y;
    }
    public static int resta(int x, int y){
        return x - y;
    }
    public static int divide(int x, int y){
        if(y==0){
            if(x>0){
                return Integer.MAX_VALUE;
            }else{
                return Integer.MIN_VALUE;
            }
        }
        return x/y;
    }
    public static int modulo(int x, int y){
       if(y==0){
           return 0;
       }
       return x%y;
    }
    public static int factorial(int x){
        if(x==1 || x==0){
            return 1;
        }
        return x*factorial(x-1);
    }
    
    
    public static void main(String[] args){
        
        int a = 10;
        int b = 6;
//        int s = suma(a,b);
//        int m = multiplica(a, b);
//        int r=resta(a, b);
//        int d=divide(a, b);
//        int mod=modulo(a, b);
//        System.out.println(a+"+"+b+"="+s);
//        System.out.println(a+"*"+b+"="+m);
//        System.out.println(a+"-"+b+"="+r);
//        System.out.println(a+"/"+b+"="+d);
//        System.out.println(a+" mod "+b+"="+s);
        
        // funciones puras con interfaces
        
        //Funcion suma = (int x, int y) -> x+y;
        Funcion suma = new Funcion(){
            @Override
            public int opera(int x, int y) {
                return x+y;
            }
        };
        
        //Funcion rest = (int x, int y) -> x-y;
        Funcion rest = new Funcion(){
            @Override
            public int opera(int x, int y) {
                return x-y;
            }
        };
        
        //Funcion multiplica = (int x, int y) -> x*y;
        Funcion multiplica = new Funcion(){
            @Override
            public int opera(int x, int y) {
                return x*y;
            }
        };
        
        //Funcion divide = (int x, int y) -> {
//            if(y==0){
//                if(x>0){
//                    return Integer.MAX_VALUE;
//                }else{
//                    return Integer.MIN_VALUE;
//                }
//            }
//            return x/y;
//        };
        
        Funcion divide = new Funcion(){
            @Override
            public int opera(int x, int y) {
                 if(y==0){
                      if(x>0){
                        return Integer.MAX_VALUE;
                      }else{
                        return Integer.MIN_VALUE;
                      }
                      }
                    return x/y;
            }
        };
        
//        Funcion modulo = (int x, int y) -> {
//            if(y==0){
//                return 0;
//            }
//            return x%y;
//        };
        
        Funcion modulo = new Funcion(){
            @Override
            public int opera(int x, int y) {
                        if(y==0){
                            return 0;
                         }
                        return x%y;
            }
        };
        
        int sum=suma.opera(a, b);
        int resta= rest.opera(a, b);
        int multi=multiplica.opera(a, b);
        int divi=divide.opera(a, b);
        int modu=modulo.opera(a,b);
       
        
        System.out.println("Puras");
        System.out.println(a+"+"+b+"="+sum);
        System.out.println(a+"*"+b+"="+multi);
        System.out.println(a+"-"+b+"="+resta);
        System.out.println(a+"/"+b+"="+divi);
        System.out.println(a+" mod "+b+"="+modu);
        System.out.println("-------------------------------------------------------------------------------------------------------");
        
//        FuncionUnaria sumaR = new FuncionUnaria(){
//            @Override
//            public int opera(int x){
//                if(x==1||x==0){
//                    return 1;
//                }
//                return x*opera(x-1);
//            }
//    
//        };
        
        //Funciones de primer orden
        
//        Funcion sumaPrimer = (x, y) -> {
//    if (y > 0) {
//        return sumaPrimer.opera(x + 1, y - 1);
//    } else {
//        return x;
//    }
//};
        Funcion sumaPrimer = new Funcion(){
            @Override
            public int opera(int x, int y){
                if(y >0){
                 return opera(x+1,y-1);
                }else{
                 return x;
                }
            }
        };
//Funcion restaPrimer = (x, y) -> {
//    if (y > 0) {
//        return restaPrimer.opera(x - 1, y - 1);
//    } else {
//        return x;
//    }
//};
        Funcion restaPrimer = new Funcion(){
            @Override
            public int opera(int x, int y){
                if(y >0){
                 return opera(x-1,y-1);
                }else{
                 return x;
                }
            }
        };
//        Funcion multiPrimer = (x, y) -> {
//    if (y > 0) {
//        return x + multiPrimer.opera(x, y - 1); 
//    } else {
//        return 0; 
//    }
//};
        Funcion multiPrimer = new Funcion() {
            @Override
            public int opera(int x, int y) {
                if (y > 0) {
                    return x + opera(x, y - 1); // Realiza una suma recursiva para multiplicar
                } else {
                    return 0; // Caso base: al multiplicar por 0, el resultado es 0
                }
            }
        };
//Funcion divPrimer = (x, y) -> {
//    if (y == 0) {
//        if (x > 0) {
//            return Integer.MAX_VALUE;
//        } else {
//            return Integer.MIN_VALUE;
//        }
//    } else {
//        if (x >= y) {
//            return 1 + divPrimer.opera(x - y, y);
//        } else {
//            return 0;
//        }
//    }
//};
        Funcion divPrimer = new Funcion(){
            @Override
            public int opera(int x, int y){
                if(y==0){
                      if(x>0){
                        return Integer.MAX_VALUE;
                      }else{
                        return Integer.MIN_VALUE;
                      }
                  }else{
                        if(x >= y){
                            return 1 + opera(x - y, y);
                        }else{
                            return 0;
                        }
                  }
            }
        };
//        Funcion modPrimer = (x, y) -> {
//    if (y == 0) {
//        return 0; 
//    } else if (x < y) {
//        return x;
//    } else {
//        return modPrimer.opera(x - y, y);
//    }
//};

        Funcion modPrimer = new Funcion(){
            @Override
            public int opera(int x, int y){
               if(y == 0){
                return 0; // No se puede calcular el módulo si el divisor es 0
               }else if(x < y){
                return x; // Cuando el dividendo es menor que el divisor, el módulo es el propio dividendo
               }else{
                return opera(x - y, y);
               }
            }
        };
        
         sum=sumaPrimer.opera(a, b);
         resta= restaPrimer.opera(a, b);
         multi=multiPrimer.opera(a, b);
         divi=divPrimer.opera(a, b);
         modu=modPrimer.opera(a,b);
        
        System.out.println("Primer orden");
        System.out.println(a+"+"+b+"="+sum);
        System.out.println(a+"*"+b+"="+multi);
        System.out.println(a+"-"+b+"="+resta);
        System.out.println(a+"/"+b+"="+divi);
        System.out.println(a+" mod "+b+"="+modu);
        
        System.out.println("-------------------------------------------------------------------------------------------------------");
        
        //Funciones de segundo orden
        
//        Funcion sumaSegundo = (x, y) -> {
//    if (y > 0) {
//        return sumaSegundo.opera(suma(x, 1), resta(y, 1));
//    } else {
//        return x;
//    }
//};
        Funcion sumaSegundo = new Funcion(){
            @Override
            public int opera(int x, int y){
                if(y >0){
                 return opera(suma(x, 1),resta(y, 1));
                }else{
                 return x;
                }
            }
        };
//        Funcion restaSegundo = (x, y) -> {
//    if (y > 0) {
//        return restaSegundo.opera(resta(x, 1), resta(y, 1));
//    } else {
//        return x;
//    }
//};
        Funcion restaSegundo = new Funcion(){
            @Override
            public int opera(int x, int y){
                if(y >0){
                 return opera(resta(x, 1),resta(y, 1));
                }else{
                 return x;
                }
            }
        };
//        Funcion multiSegundo = (x, y) -> {
//    if (y > 0) {
//        return suma(x, multiSegundo.opera(x, resta(y, 1))); // Realiza una suma recursiva para multiplicar
//    } else {
//        return 0; // Caso base: al multiplicar por 0, el resultado es 0
//    }
//};
        Funcion multiSegundo = new Funcion(){
            @Override
            public int opera(int x, int y) {
                if (y > 0) {
                    return suma(x ,opera(x, resta(y, 1))); // Realiza una suma recursiva para multiplicar
                } else {
                    return 0; // Caso base: al multiplicar por 0, el resultado es 0
                }
            }
        };
//        Funcion divSegundo = (x, y) -> {
//    if (y == 0) {
//        if (x > 0) {
//            return Integer.MAX_VALUE;
//        } else {
//            return Integer.MIN_VALUE;
//        }
//    } else {
//        if (x >= y) {
//            return suma(1, divSegundo.opera(resta(x, y), y));
//        } else {
//            return 0;
//        }
//    }
//};
        Funcion divSegundo = new Funcion(){
            @Override
            public int opera(int x, int y){
                if(y==0){
                      if(x>0){
                        return Integer.MAX_VALUE;
                      }else{
                        return Integer.MIN_VALUE;
                      }
                  }else{
                        if(x >= y){
                            return suma(1 , opera(resta(x,y), y));
                        }else{
                            return 0;
                        }
                  }
            }
        };
//        Funcion modSegundo = (x, y) -> {
//    if (y == 0) {
//        return 0; // No se puede calcular el módulo si el divisor es 0
//    } else if (x < y) {
//        return x; // Cuando el dividendo es menor que el divisor, el módulo es el propio dividendo
//    } else {
//        return modSegundo.opera(resta(x, y), y);
//    }
//};
        Funcion modSegundo = new Funcion(){
            @Override
            public int opera(int x, int y){
               if(y == 0){
                return 0; // No se puede calcular el módulo si el divisor es 0
               }else if(x < y){
                return x; // Cuando el dividendo es menor que el divisor, el módulo es el propio dividendo
               }else{
                return opera(resta(x, y), y);
               }
            }
        };
        
          sum=sumaSegundo.opera(a, b);
         resta= restaSegundo.opera(a, b);
         multi=multiSegundo.opera(a, b);
         divi=divSegundo.opera(a, b);
         modu=modSegundo.opera(a,b);
        System.out.println("Segundo orden");
        System.out.println(a+"+"+b+"="+sum);
        System.out.println(a+"*"+b+"="+multi);
        System.out.println(a+"-"+b+"="+resta);
        System.out.println(a+"/"+b+"="+divi);
        System.out.println(a+" mod "+b+"="+modu);
        System.out.println("-------------------------------------------------------------------------------------------------------");
        
                
    }
}    

